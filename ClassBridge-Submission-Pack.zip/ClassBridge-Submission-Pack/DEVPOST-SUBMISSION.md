# ForgeHacks 2026 — Devpost Submission Draft

## Project title
ClassBridge — AI-Powered Course Recovery

## Tagline / short description
ClassBridge turns course PDFs into a topic-based learning path with a baseline diagnostic, course-grounded help, focused quizzes, and mastery-based revision recommendations.

## Track
AI + Education

## Project description
### The problem
Learners can finish a lesson without knowing which concepts they have understood and which still need work. Generic practice often feels disconnected from their own course notes, and it can be difficult to decide what to revise next.

### Our solution
ClassBridge is a learning workspace that connects course material to assessment and revision. A learner can upload a text-based PDF or start with a sample course. ClassBridge extracts course text, identifies topics, offers a baseline diagnostic, answers questions using relevant passages from the selected course, generates focused practice questions, and tracks topic mastery to recommend a next learning action.

### How it works
1. **Bring course material:** Start with a built-in DBMS sample course or upload a text-based PDF.
2. **Map topics:** ClassBridge extracts text and creates a topic map.
3. **Check understanding:** A baseline diagnostic estimates initial understanding across topics.
4. **Learn from the source:** The teacher-style Q&A retrieves relevant passages from the course material. An optional OpenAI-compatible model can generate an explanation; a local fallback keeps demo mode usable without an API key.
5. **Practice and improve:** Topic-focused quizzes at different difficulty levels update mastery scores.
6. **Choose what comes next:** The mastery map and recommendation highlight topics to revisit or practice.

### Technical implementation
- React + TypeScript + Vite frontend
- Node.js + TypeScript + Express API
- SQLite persistence for course documents, topics, attempts, progress, and activity
- Poppler `pdftotext` / `pdfinfo` for extracting text and page count from text-based PDFs
- Course-text chunking and retrieval to keep answers tied to source material
- Optional OpenAI-compatible Chat Completions integration, with a local fallback

### Impact
ClassBridge aims to make revision more focused by showing learners what to work on next and tying help and practice back to their own course material. It is designed as a practical prototype that can be extended toward teacher-led remediation workflows.

### Current scope and limitations
This prototype currently focuses on an individual learner's course and progress. Classroom-level misconception grouping and teacher dashboards are not implemented yet. Scanned PDFs requiring OCR are not supported by the current upload path. Optional live AI requires a configured API key; the sample-course learning flow works in demo mode without one.

## What to add before clicking Submit
- [ ] Public GitHub repository URL
- [ ] Public 2–4 minute demo video URL
- [ ] Verified live demo URL, if deployed
- [ ] At least 3 clear screenshots (welcome, mastery map, teacher/practice flow)
- [ ] All team members added to the Devpost project
- [ ] Confirm project is in the **AI + Education** track
- [ ] Check that all claims match the version shown in the video

## 250-character short description candidate
ClassBridge turns course PDFs into a topic-based learning path with baseline diagnostics, course-grounded Q&A, focused practice quizzes, and mastery-based revision recommendations—helping learners see what to revisit next.
