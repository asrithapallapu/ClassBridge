# ClassBridge — 3-minute demo video script

**Before recording:** use the running version that you tested. If the upload flow is unreliable, demonstrate the sample DBMS course and do not imply upload was tested. Record the browser and narration clearly; avoid showing API keys or personal data.

## 0:00–0:20 — The problem
“Students often finish a chapter without knowing exactly what they understood or what to revise next. ClassBridge connects course material, assessment, focused practice, and progress in one learning workspace.”

## 0:20–0:40 — Start the course
Open the welcome page and click **Start learning with a sample course**. Briefly point out the sample DBMS course and the dark/light theme option.

## 0:40–1:05 — Show the topic map
Open **Overview** and **Mastery map**. Explain that topics are tracked separately, so the learner can identify where to focus instead of relying only on one overall score.

## 1:05–1:35 — Baseline diagnostic
Open **Baseline**, start the diagnostic, answer a few questions, and submit. Explain that this establishes a starting point for topic-level revision.

## 1:35–2:05 — Course-grounded help
Open **AI Teacher**, select a topic, and ask a question clearly related to that topic. Show the response and its source excerpt if visible. Say that live model generation is optional and demo mode can use a local retrieval-based fallback.

## 2:05–2:35 — Focused practice
Open **Practice**, choose a topic and difficulty, answer the quiz, and submit. Point out the feedback and updated mastery/recommendation if the tested flow updates it correctly.

## 2:35–2:50 — Return to next steps
Return to the mastery map or overview and show the recommended topic/action. Summarize: “ClassBridge helps learners move from course notes to a clear next step.”

## 2:50–3:00 — Close
“ClassBridge is our AI + Education prototype. Our next step is to extend this individual learning workflow toward teacher-led classroom remediation.”

## Recording checklist
- [ ] Publicly accessible video, 2–4 minutes maximum
- [ ] Show real working screens, not only slides
- [ ] Use captions or clear narration
- [ ] Don't expose secrets or API keys
- [ ] Keep one backup recording of the sample-course path
- [ ] Add the public video URL to Devpost
